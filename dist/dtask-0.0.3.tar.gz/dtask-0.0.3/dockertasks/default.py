""""""

DEFAULT_VOLUMES = "/home:/home /root:/root"
DEFAULT_ADAPTER = "ens37"
DEFAULT_CPU_PER_NODE = 2
